#include "Server.h"
#include <iostream>

Server::Server(Uint16 port, Uint16 max_clients)
{
	if(SDL_Init(0)) throw SDL_GetError();
	if (SDLNet_Init()) throw SDLNet_GetError();

	if (SDLNet_ResolveHost(&server_ip, nullptr, port))
	{
		throw "Invalid port";
	}

	if(!(server_socket = SDLNet_TCP_Open(&server_ip)))
	{
		throw SDLNet_GetError();
	}

	if (!(socket_set = SDLNet_AllocSocketSet(max_clients + 1)))
	{
		throw SDLNet_GetError();
	}

	if (SDLNet_TCP_AddSocket(socket_set, server_socket) == -1)
	{
		throw SDLNet_GetError();
	}

	this->port = port;
	this->max_clients = max_clients;
}

Server::~Server()
{
	for (auto& client : clients)
	{
		SDLNet_TCP_DelSocket(socket_set, client);
		SDLNet_TCP_Close(client);
	}

	SDLNet_FreeSocketSet(socket_set);
	SDLNet_TCP_Close(server_socket);
	SDLNet_Quit();
	SDL_Quit();
}

std::string Server::get_ip(TCPsocket client)
{
	IPaddress* client_ip = SDLNet_TCP_GetPeerAddress(client);
	Uint32 ip = SDLNet_Read32(&client_ip->host);

	return 
		std::to_string((ip & 0xFF000000) >> 24) + "." +
		std::to_string((ip & 0x00FF0000) >> 16) + "." +
		std::to_string((ip & 0x0000FF00) >> 8)  + "." +
		std::to_string((ip & 0x000000FF));
}

Uint16 Server::get_port(TCPsocket client)
{
	IPaddress* client_ip = SDLNet_TCP_GetPeerAddress(client);
	Uint16 port = SDLNet_Read16(&client_ip->port);
	return port;
}

int Server::start()
{
	std::cout << "\nListening on port " << port << "..." << std::endl;
	while (true)
	{
		int sockets_ready = SDLNet_CheckSockets(socket_set, 0);
		if (sockets_ready == -1)
		{
			throw SDLNet_GetError();
		}
		else if (sockets_ready > 0)
		{
			if (SDLNet_SocketReady(server_socket))
			{
				if (clients.size() < max_clients)
				{
					TCPsocket client = SDLNet_TCP_Accept(server_socket);
					if (client)
					{
						Message msg = CONNECTED;
						if (SDLNet_TCP_Send(client, &msg, 1) < 1)
						{
							SDLNet_TCP_Close(client);
						}
						else
						{
							if (SDLNet_TCP_AddSocket(socket_set, client) == -1)
							{
								throw SDLNet_GetError();
							}

							std::cout << get_ip(client) << ":" << 
								         get_port(client) << " connected" 
									  << std::endl;
							clients.push_back(client);
						}
					}
				}
				else
				{
					TCPsocket client = SDLNet_TCP_Accept(server_socket);
					if (client)
					{
						Message msg = FULL;
						SDLNet_TCP_Send(client, &msg, 1);
						SDLNet_TCP_Close(client);
					}
				}
			}

			int client_counter = 0;
			for (auto& client : clients)
			{
				if (SDLNet_SocketReady(client))
				{
					Message msg;
					if (SDLNet_TCP_Recv(client, &msg, 1) <= 0)
					{
						std::cout << get_ip(client) << ":" <<
									 get_port(client) << " disconnected"
								  << std::endl;

						SDLNet_TCP_DelSocket(socket_set, client);
						SDLNet_TCP_Close(client);
						clients.erase(clients.begin() + client_counter);
					}
					else
					{

					}
				}
				client_counter++;
			}
		}
	}
}