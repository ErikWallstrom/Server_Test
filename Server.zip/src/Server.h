#ifndef SERVER_H
#define SERVER_H

#include "../include/SDL2/SDL_net.h"
#include <vector>
#include <string>
class Server
{
private:
	enum Message : char
	{
		CONNECTED,
		FULL
	};

	IPaddress server_ip;
	TCPsocket server_socket;
	SDLNet_SocketSet socket_set;

	std::vector<TCPsocket> clients;

	Uint16 port;
	Uint16 max_clients;

	std::string get_ip(TCPsocket client);
	Uint16 get_port(TCPsocket client);

public:

	Server(Uint16 port, Uint16 max_clients);
	~Server();

	int start();
};

#endif